// Érdekességek listája
const facts = [
    "A láva hőmérséklete 700–1200 °C között mozog.",
    "A vulkánok 80%-a az óceánok alatt található.",
    "A leggyorsabb lávafolyás sebessége meghaladta a 60 km/h-t.",
    "A Holdon és a Marson is léteznek vulkanikus lávaformák.",
    "A vulkánkitörések során kibocsátott gázok a Föld légkörét is alakították."
];

// Érdekességek megjelenítése
document.getElementById('factButton').addEventListener('click', () => {
    const randomFact = facts[Math.floor(Math.random() * facts.length)];
    const factDisplay = document.getElementById('factDisplay');
    factDisplay.textContent = randomFact;
    factDisplay.classList.remove('hidden');
});
